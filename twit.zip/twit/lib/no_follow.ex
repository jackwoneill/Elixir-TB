defmodule NoFollow do

	def pop_followers_list(list, 0) do
		list
	end

	def pop_followers_list(list, nc) do
		fols = ExTwitter.follower_ids("politicuck", count: 200, cursor: nc)
		pop_followers_list(fols.items ++ list, fols.next_cursor)
	end


	##### BEGIN FINDING FOLLOWED USERS #####
	def pop_followed_list(list, 0) do
		list
	end

	def pop_followed_list(list, nc) do
		followed = ExTwitter.friend_ids("politicuck", count: 500, cursor: nc)
		pop_followed_list(followed.items ++ list, followed.next_cursor)
	end
	##### END FINDING FOLLOWED USERS ######

	def prepare_unfollow(followed_list, followers_list) do
		to_unfollow = followed_list -- followers_list

		lists = split(to_unfollow)
		half_1 = elem(lists, 0)
		half_2 = elem(lists, 1)

		lists_2 = split(half_1)
		lists_3 = split(half_2)

		sub_1 = elem(lists_2, 0)
		sub_2 = elem(lists_2, 1)

		sub_3 = elem(lists_3, 0)
		sub_4 = elem(lists_3, 1)

		spawn fn -> unfollow_users(sub_1) end
		spawn fn -> unfollow_users(sub_2) end
		spawn fn -> unfollow_users(sub_3) end
		spawn fn -> unfollow_users(sub_4) end
	end

	def unfollow_users(list) do
		IO.puts "Unfollowing"
		try do
		  for n <- list, do: ExTwitter.unfollow(n)
		catch
		  ExTwitter.RateLimitExceededError -> 
		  	IO.puts "Rate Limit Exceeded, process exiting"
		  	exit(:shutdown)
		end
		
		
	end

	def split(list) do
	  len = round(length(list)/2)
	  Enum.split(list, len)
	end

	def main do
		a = ExTwitter.user("politicuck")
		count = a.followers_count

		prepare_unfollow(pop_followed_list([], -1), pop_followers_list([], -1))
		
		#num_to_unfollow = length(to_unfollow)
		
	end


end
