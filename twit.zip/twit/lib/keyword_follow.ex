defmodule KeywordFollow do


	#######################		find_and_follow/1 			#####################
	# 	Iterates over LIST, spawns new process, calls find_and_follow/2 		#
	#																			#
	# 	- ARGUMENTSS -															#
	#																			#
	# 	LIST - A list of maps in form %{:to_search, :count}						#
	#############################################################################

	#######################		find_and_follow/2 			#####################
	# 	Searches for COUNT tweets containing STRING, follows users that tweeted	#
	#																			#
	# 	- ARGUMENTSS -															#
	#																			#
	# 	STRING - The keyword(s) to search for 								   	#
	# 	COUNT - How many tweets containing STRING to search for, MAX = 200      #
	#############################################################################


	def find_and_follow(list) do
		for item <- list, do: spawn fn -> find_and_follow(item[:to_search], item[:count]) end
	end


	def find_and_follow(string, count) do
		IO.puts("BEGAN Searching For: \"" <> string <> "\", COUNT: " <> to_string(count))
		tweets = ExTwitter.search(string, count: count, result_type: :recent, lang: :en)
		followed = 0
		for n <- tweets do 
			try do
				unless ExTwitter.follow(String.to_integer(n.user.id_str)).following == true do
				  followed = followed + 1
				end
			rescue
				ExTwitter.ConnectionError -> IO.puts "Connection Error, I have no clue why this happens"
				ExTwitter.RateLimitExceededError -> 
					IO.puts "RATE LIMIT EXCEEDED, NEED TO EXIT"
					System.halt(0)
				e in ExTwitter.Error -> IO.puts "General error thrown, some fucko probably blocked you, will try to continue"
			end
			
		end
		IO.puts("FINISHED Searching For: \"" <> string <> "\", FOLLOWED: " <> to_string(followed))
	end

	def main do
		# @JESSE
		# MUST BE A SPACE BETWEEN THE ':' AND THE VALUE
		# ADD AS MANY KEYWORD AS YOU'D LIKE
		# SPACES ARE ALLOWED
		# MUST BE COMMA AFTER ALL ITEMS EXCEPT LAST ONE
		# MAX COUNT IS 200
		# YOU CAN USE '#' TO COMMENT OUT(NOT EXECUTE) A LINE THUS YOU CAN MAKE A LARGE 
		#	 LIST, AND COMMENT OUT WHICH ONES YOU DONT WANT TO RUN AT THAT TIME

		keywords = [
		  %{to_search: "MAGA", count: 25},
		  %{to_search: "CCOT", count: 10},
		  %{to_search: "trumptrain", count: 10},
		  %{to_search: "islamistheproblem", count: 10},
		  %{to_search: "banislam", count: 5}
		]
		find_and_follow(keywords)

	end

end